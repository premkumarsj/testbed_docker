#! /usr/bin/perl
#Proper chunked response finishing in one NSB
#
use CGI ;
print "Content-type: text/html; charset=utf-8\r\n" ;
print "Transfer-Encoding:chunked\r\n" ;
print "Connection: Keep-Alive\r\n\r\n" ;
print "1d\r\n";
print "<html><head>TEST</head><body>\r\n";
for($i = 0; $i<= 25;$i++)
{
print "2c\r\n";
print "1"x44;
print "\r\n";
}
print "e\r\n";
print "</body></html>\r\n";
print "0\r\n";
print "\r\n";
