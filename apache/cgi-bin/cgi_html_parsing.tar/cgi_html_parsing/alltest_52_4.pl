#! /usr/bin/perl

use CGI ;
my $query = new CGI;
my $size = $query->param('size');
my $iteration = int($size/5);
print "Content-type: text/html; charset=utf-8\r\n" ;
print "Transfer-Encoding:chunked\r\n" ;
print "Connection: Keep-Alive\r\n\r\n" ;
print "0429\r\n";
print "<html><head><link rel=\"stylesheet\" type=\"text/css\" href=\"css_minify_code_removals.css\" /><script type=\"text/javascript\" src=\"formval.js\"></script><style>p.second{font: 12pt/14pt sans-serif}</style></head><body>";
print "1"x790;
print "<style>p.third{font: 12pt/14pt sans-serif}</style>";
print "<style>p.third{";
print "\r\n";
for($i = 0; $i<= $iteration;$i++)
{
print "04\r\n";
print "1"x4;
print "\r\n";
}
print "AB\r\n";
print "font: 12pt/14pt sans-serif}</style>";
print "<style>p.third{font: 12pt/14pt sans-serif}</style>";
print "</body></html>\r\n";
print "<title12345678909>this is a long tag let test for it</title12345678909>\r\n";
print "0\r\n";
print "\r\n";
